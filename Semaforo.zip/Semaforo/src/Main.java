import javax.swing.*;
import java.awt.*;
import java.util.concurrent.Semaphore;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaSemaforo ventana = new VentanaSemaforo();
            ventana.setVisible(true);
        });
    }
}

class VentanaSemaforo extends JFrame {

    private static final int CAPACIDAD = 5;
    private static final int PAUSA_LIBRE_MS = 2000;
    private static final int PASO_LLENADO_MS = 700;
    private static final int PAUSA_LLENO_MS = 2000;
    private static final int PASO_LIBERADO_MS = 700;

    private final Semaphore semaphore = new Semaphore(CAPACIDAD, true);
    private final PanelSemaforo panelSemaforo;
    private final JLabel labelEstado;
    private final JLabel labelOcupacion;

    private volatile int ocupados = 0;
    private final Object lock = new Object();

    public VentanaSemaforo() {
        setTitle("Simulación de Semáforo con Hilos (java.util.concurrent.Semaphore)");
        setSize(360, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        panelSemaforo = new PanelSemaforo();
        add(panelSemaforo, BorderLayout.CENTER);

        labelEstado = new JLabel("Estado: LIBRE", SwingConstants.CENTER);
        labelEstado.setFont(new Font("Arial", Font.BOLD, 18));

        labelOcupacion = new JLabel("Ocupación: 0 / " + CAPACIDAD, SwingConstants.CENTER);
        labelOcupacion.setFont(new Font("Arial", Font.PLAIN, 14));

        JPanel panelInferior = new JPanel(new GridLayout(2, 1));
        panelInferior.add(labelEstado);
        panelInferior.add(labelOcupacion);
        add(panelInferior, BorderLayout.SOUTH);

        iniciarHiloSimulador();
    }

    private void iniciarHiloSimulador() {
        Thread hiloSimulador = new Thread(() -> {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    Thread.sleep(PAUSA_LIBRE_MS);

                    for (int i = 0; i < CAPACIDAD; i++) {
                        semaphore.acquire();
                        actualizarOcupacion(1);
                        Thread.sleep(PASO_LLENADO_MS);
                    }
                    Thread.sleep(PAUSA_LLENO_MS);
                    for (int i = 0; i < CAPACIDAD; i++) {
                        semaphore.release();
                        actualizarOcupacion(-1);
                        Thread.sleep(PASO_LIBERADO_MS);
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        hiloSimulador.setDaemon(true);
        hiloSimulador.start();
    }

    private void actualizarOcupacion(int delta) {
        synchronized (lock) {
            ocupados += delta;
        }
        SwingUtilities.invokeLater(this::refrescarVista);
    }

    private void refrescarVista() {
        String estado;
        Color color;

        if (ocupados <= 0) {
            estado = "LIBRE";
            color = Color.GREEN;
        } else if (ocupados >= CAPACIDAD) {
            estado = "LLENO";
            color = Color.RED;
        } else {
            estado = "OCUPADO PARCIALMENTE";
            color = Color.YELLOW;
        }

        labelEstado.setText("Estado: " + estado);
        labelOcupacion.setText("Ocupación: " + ocupados + " / " + CAPACIDAD);
        panelSemaforo.setColorActivo(color);
    }
}

class PanelSemaforo extends JPanel {

    private Color colorActivo = Color.GREEN; // estado inicial: libre

    public PanelSemaforo() {
        setPreferredSize(new Dimension(300, 350));
        setBackground(Color.DARK_GRAY);
    }

    public void setColorActivo(Color color) {
        this.colorActivo = color;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int ancho = getWidth();
        int diametro = 80;
        int x = (ancho - diametro) / 2;

        g2.setColor(Color.BLACK);
        g2.fillRoundRect(x - 20, 30, diametro + 40, 300, 30, 30);

        dibujarCirculo(g2, x, 50, diametro, Color.RED);
        dibujarCirculo(g2, x, 150, diametro, Color.YELLOW);
        dibujarCirculo(g2, x, 250, diametro, Color.GREEN);
    }

    private void dibujarCirculo(Graphics2D g2, int x, int y, int diametro, Color color) {
        boolean encendido = colorActivo.equals(color);
        g2.setColor(encendido ? color : color.darker().darker());
        g2.fillOval(x, y, diametro, diametro);
        g2.setColor(Color.BLACK);
        g2.drawOval(x, y, diametro, diametro);
    }
}